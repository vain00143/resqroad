#!/usr/bin/env bash
set -euo pipefail
bash /workspace/resqroad-video/scripts/start-db.sh
cd /workspace/resqroad
exec node --env-file=/workspace/resqroad-video/state/app.env serve.js
