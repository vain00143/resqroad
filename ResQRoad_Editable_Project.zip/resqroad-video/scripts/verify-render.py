import json,subprocess,math
from pathlib import Path
p=Path('/workspace/resqroad-video/exports/ResQRoad_Technical_Test.mp4')
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
video=next(x for x in info['streams'] if x['codec_type']=='video')
audio=next(x for x in info['streams'] if x['codec_type']=='audio')
assert (video['width'],video['height'])==(1920,1080)
assert video['codec_name']=='h264'
assert video['r_frame_rate']=='30/1'
assert audio['codec_name']=='aac' and audio['channels']==2
assert abs(float(info['format']['duration'])-8)<0.15
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(p),'-f','null','-'],check=True)
out=subprocess.run(['ffmpeg','-hide_banner','-i',str(p),'-vn','-af','volumedetect','-f','null','-'],check=True,capture_output=True,text=True)
assert 'mean_volume: -inf' not in out.stderr and 'mean_volume:' in out.stderr
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss','3','-i',str(p),'-frames:v','1',str(p.parent/'technical-test-frame.jpg')],check=True)
report={'video':{'codec':video['codec_name'],'width':video['width'],'height':video['height'],'fps':video['r_frame_rate']},'audio':{'codec':audio['codec_name'],'channels':audio['channels'],'source':'generated technical test tone; no supplied narration'},'duration':float(info['format']['duration']),'full_decode':'passed','non_silent_audio':'passed','subtitle_source':'ResQRoad_Technical_Test.srt'}
(p.parent/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
