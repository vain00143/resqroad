const assert=require('node:assert/strict');
(async()=>{
 for(const route of ['/api/health','/api/health/db','/']){
  const r=await fetch('http://127.0.0.1:8001'+route);
  assert.equal(r.status,200,route);
  const body=await r.text();
  assert.ok(route==='/'?body.includes('ResQRoad'):body.includes('ok'),route);
 }
 console.log('PASS: develop website, API, and live database readiness');
})().catch(e=>{console.error(e);process.exitCode=1;});
