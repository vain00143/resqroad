"""Download a pinned official Sherpa/Whisper model with TLS and SHA-256 checks."""
from pathlib import Path
import hashlib,tarfile,urllib.request
root=Path('/workspace/resqroad-video/state/models');root.mkdir(parents=True,exist_ok=True)
archive=root/'sherpa-onnx-whisper-base.en.tar.bz2'
expected='475bc7052ce299c007f6d5d5407ba8601f819a2867f6eecee510ed17df581542'
if not archive.exists():
 temporary=archive.with_suffix('.download')
 urllib.request.urlretrieve('https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-base.en.tar.bz2',temporary)
 if hashlib.sha256(temporary.read_bytes()).hexdigest()!=expected:raise RuntimeError('Official model archive checksum mismatch; do not use this download')
 temporary.rename(archive)
assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected,'Cached archive checksum mismatch'
with tarfile.open(archive) as tar:tar.extractall(root,filter='data')
print('Official base.en model verified and available locally.')
