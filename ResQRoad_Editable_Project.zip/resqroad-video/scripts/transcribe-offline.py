"""Offline English transcription; review automatic captions before publication."""
from pathlib import Path
import sys,subprocess,json,textwrap
import numpy as np
import sherpa_onnx
from faster_whisper.vad import get_speech_timestamps,VadOptions
def stamp(t):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{s:02},{ms:03}'
def main():
 if len(sys.argv)!=3:raise SystemExit('Usage: transcribe-offline.py input_audio output.srt')
 model=Path('/workspace/resqroad-video/state/models/sherpa-onnx-whisper-base.en')
 r=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(model/'base.en-encoder.int8.onnx'),decoder=str(model/'base.en-decoder.int8.onnx'),tokens=str(model/'base.en-tokens.txt'),language='en',task='transcribe',num_threads=3)
 samples=np.frombuffer(subprocess.check_output(['ffmpeg','-hide_banner','-loglevel','error','-i',sys.argv[1],'-map','0:a:0','-ac','1','-ar','16000','-f','f32le','-']),np.float32)
 regions=get_speech_timestamps(samples,VadOptions(min_silence_duration_ms=500,speech_pad_ms=150,max_speech_duration_s=12))
 groups=[]
 for region in regions:
  if groups and (region['end']-groups[-1]['start'])/16000<12:groups[-1]['end']=region['end']
  else:groups.append(dict(region))
 lines=[]
 for n,g in enumerate(groups,1):
  s=r.create_stream();s.accept_waveform(16000,samples[g['start']:g['end']]);r.decode_stream(s)
  text=json.loads(str(s.result))['text'].strip()
  lines.append(f"{n}\n{stamp(g['start']/16000)} --> {stamp(g['end']/16000)}\n"+'\n'.join(textwrap.wrap(text,width=52)))
 Path(sys.argv[2]).write_text('\n\n'.join(lines)+'\n');print(f'Transcribed {len(lines)} segments. Review names and caption wording before publication.')
if __name__=='__main__':main()
