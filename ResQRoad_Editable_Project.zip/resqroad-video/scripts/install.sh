#!/usr/bin/env bash
set -euo pipefail
task_root=/workspace/resqroad-video
for task_tool in node npm ffmpeg ffprobe chromium docker python3; do
  command -v "$task_tool" >/dev/null || { echo "Missing base tool: $task_tool" >&2; exit 1; }
done
test -f /workspace/resqroad/package-lock.json
test -f /workspace/resqroad/server/app.js
mkdir -p "$task_root/state/mysql" "$task_root/state/models" "$task_root/project/public" "$task_root/exports"
cd /workspace/resqroad
npm ci --no-audit --no-fund
cd "$task_root/project"
npm ci --no-audit --no-fund
test -x "$task_root/.venv/bin/python" || python3 -m venv "$task_root/.venv"
"$task_root/.venv/bin/python" -m pip install -r "$task_root/requirements.lock.txt"
"$task_root/.venv/bin/python" "$task_root/scripts/download-model.py"
bash "$task_root/scripts/setup-app.sh"
echo 'Tools installed and isolated demo database prepared. Start the app separately.'
