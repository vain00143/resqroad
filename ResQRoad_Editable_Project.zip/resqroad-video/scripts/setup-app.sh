#!/usr/bin/env bash
set -euo pipefail
bash /workspace/resqroad-video/scripts/start-db.sh
cd /workspace/resqroad
node --env-file=/workspace/resqroad-video/state/app.env tools/db-setup.js
node --env-file=/workspace/resqroad-video/state/app.env tools/seed.js
