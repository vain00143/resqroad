#!/usr/bin/env bash
set -euo pipefail
task_root=/workspace/resqroad-video
task_image=mariadb@sha256:d1891ede5a559f1086f55053bb8cc1569b0298338c4d72d71725a7f74f6ba620
task_docker() {
  env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH docker --host=unix:///var/run/docker.sock "$@"
}
mkdir -p "$task_root/state"
if [ ! -f "$task_root/state/database.env" ]; then
  python3 - <<'PY'
from pathlib import Path
import secrets,os
p=Path('/workspace/resqroad-video/state')
password=secrets.token_hex(24)
files={'database.env':f'MARIADB_ROOT_PASSWORD={password}\nMARIADB_ROOT_HOST=%\n',
       'app.env':f'DB_HOST=127.0.0.1\nDB_PORT=3307\nDB_USER=root\nDB_PASSWORD={password}\nDB_NAME=resqroad_video_demo\nHOST=127.0.0.1\nPORT=8001\nSTORAGE_DIR=/workspace/resqroad-video/state/uploads\nCOOKIE_SECURE=false\n'}
for name,content in files.items():
 file=p/name
 with file.open('x') as out: out.write(content)
 os.chmod(file,0o600)
PY
fi
if task_docker container inspect resqroad-video-db >/dev/null 2>&1; then
  task_docker start resqroad-video-db >/dev/null
else
  task_docker image inspect "$task_image" >/dev/null 2>&1 || task_docker pull "$task_image"
  task_docker run -d --name resqroad-video-db --label resqroad.purpose=video-demo \
    -p 127.0.0.1:3307:3306 --env-file "$task_root/state/database.env" \
    --mount "type=bind,src=$task_root/state/mysql,dst=/var/lib/mysql" "$task_image" >/dev/null
fi
for task_try in $(seq 1 45); do
  if task_docker exec resqroad-video-db healthcheck.sh --connect --innodb_initialized >/dev/null 2>&1; then
    echo 'Isolated MariaDB ready on loopback port 3307'
    exit 0
  fi
  sleep 1
done
echo 'MariaDB readiness failed; inspect docker logs resqroad-video-db' >&2
exit 1
