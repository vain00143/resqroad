"""Compatibility entry point for the verified offline transcription workflow."""
from pathlib import Path
import runpy
runpy.run_path(str(Path(__file__).with_name("transcribe-offline.py")),run_name="__main__")
