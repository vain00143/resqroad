from pathlib import Path
import subprocess,json
root=Path('/workspace/resqroad-video');export=root/'exports';edit=json.loads((root/'production/edit.json').read_text());total=edit['durationInFrames'];size=(total+3)//4
def probe(p):return json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
parts=[]
for i in range(4):
 p=root/'state/render-parts'/f'part-{i}.mp4';info=probe(p);v=next(s for s in info['streams'] if s['codec_type']=='video')
 assert int(v['nb_frames'])==min(size,total-i*size),(p,v.get('nb_frames'))
 assert (v['width'],v['height'],v['r_frame_rate'])==(1920,1080,'30/1')
 parts.append(p)
listing=root/'state/render-parts/concat.txt';listing.write_text('\n'.join(f"file '{p}'" for p in parts))
visual=export/'ResQRoad_Promo_Visuals.mp4'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(listing),'-c','copy','-movflags','+faststart',str(visual)],check=True)
vinfo=next(s for s in probe(visual)['streams'] if s['codec_type']=='video')
if vinfo.get('color_range')=='pc' or vinfo['pix_fmt'].startswith('yuvj'):
 limited=export/'ResQRoad_Promo_Visuals_Standard.mp4'
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(visual),'-vf','scale=in_range=full:out_range=tv:out_color_matrix=bt709,format=yuv420p','-c:v','libx264','-threads','3','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-color_range','tv','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-an','-movflags','+faststart',str(limited)],check=True)
 visual=limited
 print('Normalized full-range render to standard limited-range BT.709.',flush=True)
final=export/'ResQRoad_Promo_Final.mp4';duration=total/30
audio=export/'ResQRoad_Promo_Audio.wav'
if not audio.exists():audio=export/'ResQRoad_Promo_Audio.m4a'
encoding=['-c:a','aac','-b:a','256k','-ar','48000'] if audio.suffix=='.wav' else ['-c:a','copy']
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(visual),'-i',str(audio),'-i',str(export/'ResQRoad_Promo_Subtitles.srt'),'-map','0:v:0','-map','1:a:0','-map','2:0','-c:v','copy',*encoding,'-c:s','mov_text','-metadata:s:s:0','language=eng','-disposition:s:0','0','-t',str(duration),'-movflags','+faststart','-metadata','title=ResQRoad — Safer roads start with one report',str(final)],check=True)
print('Clean master with optional English subtitles exported.',flush=True)
captioned=export/'ResQRoad_Promo_Captioned.mp4'
vf=f"ass=filename={export/'ResQRoad_Promo_Subtitles.ass'}:fontsdir={root/'project/public/production'}"
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(final),'-map','0:v:0','-map','0:a:0','-vf',vf,'-c:v','libx264','-threads','3','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart',str(captioned)],check=True)
print('Burned-in caption version exported.',flush=True)
