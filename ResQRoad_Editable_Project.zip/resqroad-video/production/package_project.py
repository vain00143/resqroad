from pathlib import Path
import zipfile,subprocess,json,hashlib
root=Path('/workspace/resqroad-video');staging=root/'state/package-audio';staging.mkdir(parents=True,exist_ok=True)
files={}
def add(p,rel=None):
 p=Path(p);rel=Path(rel) if rel else p.relative_to(root)
 assert 'state' not in rel.parts and '.venv' not in rel.parts and 'node_modules' not in rel.parts
 assert not p.name.endswith('.env')
 files[str(Path('resqroad-video')/rel)]=p
add(root/'production/README.md','README.md')
add(root/'AGENTS.md')
add(root/'requirements.lock.txt')
for name in ['package.json','package-lock.json','render-promo.mjs','bundle-promo.mjs','preview-promo.mjs','capture-production.cjs','capture-repair-detail.cjs']:
 add(root/'project'/name)
for folder in ['project/src','project/public','inputs/member-photos','inputs/references']:
 for p in (root/folder).rglob('*'):
  if not p.is_file():continue
  rel=p.relative_to(root)
  if str(rel)=='project/src/index.jsx':continue
  if p.name in ['test-tone.wav','app-capture.webm','app-capture.mp4','dashboard.png','reports.png']:continue
  if p.name in ['dialogue.wav','score-original.wav']:continue
  if p.parent.name=='audio' and not p.name.endswith('-master.wav'):continue
  add(p)
add(root/'inputs/guide.pdf')
for p in (root/'production').iterdir():
 if p.is_file() and p.suffix in ['.py','.json','.md'] and not p.name.startswith('qc-'):add(p)
for p in (root/'scripts').iterdir():
 if p.is_file() and p.suffix in ['.py','.sh','.cjs']:add(p)
for p in (root/'inputs/voiceovers').iterdir():
 if p.suffix.lower()=='.mov':
  audio=staging/(p.stem+'.m4a')
  subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(p),'-map','0:a:0','-c:a','copy','-vn',str(audio)],check=True)
  add(audio,Path('inputs/voiceovers')/audio.name)
 elif p.suffix.lower()=='.mp3':add(p)
 elif p.name=='inventory.json':add(p)
master=staging/'ResQRoad_Promo_Audio.m4a'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(root/'exports/ResQRoad_Promo_Final.mp4'),'-map','0:a:0','-c:a','copy','-vn',str(master)],check=True)
add(master,'exports/ResQRoad_Promo_Audio.m4a')
for name in ['ResQRoad_Promo_Subtitles.srt','ResQRoad_Promo_Subtitles.ass','ResQRoad_Validation.json']:
 add(root/'exports'/name)
out=Path('/workspace/shared/ResQRoad_Editable_Project.zip')
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for rel,p in sorted(files.items()):z.write(p,rel)
with zipfile.ZipFile(out) as z:
 assert z.testzip() is None
 assert b'Paul Benedick J. Santiago' in z.read('resqroad-video/inputs/member-photos/member-map.json')
 assert all('/state/' not in n and not n.endswith('.env') for n in z.namelist())
print(json.dumps({'archive':str(out),'files':len(files),'bytes':out.stat().st_size,'private_state_included':False},indent=2))
