from pathlib import Path
import json,wave
import numpy as np
import sherpa_onnx

root=Path('/workspace/resqroad-video');model=root/'state/models/sherpa-onnx-whisper-base.en'
r=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=str(model/'base.en-encoder.int8.onnx'),decoder=str(model/'base.en-decoder.int8.onnx'),tokens=str(model/'base.en-tokens.txt'),language='en',task='transcribe',num_threads=3)
raw=json.loads((root/'production/transcripts-raw.json').read_text());out={}
for name,data in raw.items():
 with wave.open(str(root/'state/audio'/(name+'.wav'))) as f: samples=np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
 groups=[]
 for region in data['segments']:
  if groups and region['end']-groups[-1]['start']<27:groups[-1]['end']=region['end']
  else:groups.append({'start':region['start'],'end':region['end']})
 for group in groups:
  stream=r.create_stream();stream.accept_waveform(16000,samples[int(group['start']*16000):int(group['end']*16000)]);r.decode_stream(stream)
  group['text']=json.loads(str(stream.result))['text'].strip()
 out[name]=groups
 (root/'production/transcripts-context.json').write_text(json.dumps(out,indent=2)+'\n')
 print(name,' '.join(g['text'] for g in groups),flush=True)
