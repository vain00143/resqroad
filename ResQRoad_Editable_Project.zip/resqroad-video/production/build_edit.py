"""Editorial timeline, corrected captions, and reproducible narration assembly."""
from pathlib import Path
import json,subprocess,textwrap,concurrent.futures,shutil
root=Path('/workspace/resqroad-video');pub=root/'project/public/production';(pub/'audio').mkdir(exist_ok=True);(root/'state/audio').mkdir(parents=True,exist_ok=True)
raw=json.loads((root/'production/transcripts-raw.json').read_text())
corrected={
'IMG_0463':[
'Every day,','we drive over them.','Potholes.','They damage our vehicles and put people in danger.','Maybe you reported one and never heard back.','So...','who is actually going to fix it?','Today,','we are the first group of BSIT 3H-G2.','And this','is our promotional video','for IT305,','Advanced Web Development.','In this subject,','we build web applications that solve real community problems.','And here is ours.','Introducing','ResQRoad:','a web and mobile-friendly pothole reporting and monitoring system','for local government units.','In this system,','it connects three groups on one single platform:','residents who report the damage,','administrators who verify it,','and road crews','who fix it.','One report.','One record.','From the first photo to the verified repair.','Too often, reporting road damage is slow and unclear.','Residents get no feedback.','The same pothole is reported again and again and again and again.','And road offices lack a clear picture.','Our group saw that gap,','and we decided to design and build','ResQRoad to close that gap.'],
'IMG_0474':[
'Now, the LGU side.','Administrators start at the dashboard,','which shows new reports, repairs waiting for verification, and high-severity issues.','In the review queue, every report opens with its photos, location, and status timeline.','A report is never verified just because it was submitted.','The administrator checks the evidence,','then verifies it,','rejects it,','or marks it as a duplicate.','And every decision is recorded in the report history.','Once verified,','a report goes to Task Dispatch,','highest severity first.','Administrators assign each job','to a crew,','and the workload panel keeps the work balanced.','In the field,','crews see jobs on a map,','get directions and submit photos of the finished repair,','which an administrator verifies before the report is closed.'],
'IMG_0476':['Before you report, open the live map.','Every reported pothole appears as a pin,','color-coded by severity so you can see what is already on record and avoid duplicates.','With your report ID, Track a Report shows its status anytime.'],
'IMG_0479':['Behind every report is data.','The Insights page shows the resolution rate,','average time to verify and resolve,','and open high-severity cases,','with monthly and severity breakdowns,','ready to print or export to CSV.'],
'IMG_0480':['From pothole to fixed in four steps:','Report. Verify. Repair. Resolve.'],
'IMG_0483':['One transparent workflow,','so residents always know where their report stands.'],
'IMG_0484':['And we tested it from the first photo to the closed report.'],
'IMG_0485':['ResQRoad was built','because every resident deserves safer roads,','and every LGU deserves better tools to fix them.'],
'IMG_0492':['Report it.','Track it.','Watch your community’s roads get fixed.','With ResQRoad, safer roads start with one report.'],
'IMG_0514':["Let’s start with residents.",'Reporting takes four simple steps.','First,','give the damage a short title.','Choose its severity and describe what you see.','Low is a small crack,','medium slows drivers down,','and high is a deep, dangerous pothole.','Second,','set the location.','Zoom in and place the pin right on the damage.','Third, add photos:','a wide shot for context','and a close-up','of the damage.','Finally,','review and submit.','Your name stays private,','and only the Road Maintenance Office sees who filed the report.','You get a report ID right away.','And in My Reports,','you can follow every update from submitted to resolved.']}
for name,lines in corrected.items():assert len(lines)==len(raw[name]['segments']),(name,len(lines))
sections=[];cursor=0
def add(key,label,duration=None,voice=None,clip=None):
 global cursor
 if voice:duration=clip[1]-clip[0]
 frames=round(duration*30);entry={'id':key,'label':label,'startFrame':cursor,'durationInFrames':frames}
 if voice:entry['voice']={'file':voice,'in':clip[0],'out':clip[1]}
 sections.append(entry);cursor+=frames;return entry
add('opening','RESQROAD',2.6)
add('hook','SAFER ROADS',voice='IMG_0463',clip=(1.0,17.1))
add('course-card','OUR PROJECT',1.2)
add('course','IT305 · ADVANCED WEB DEVELOPMENT',voice='IMG_0463',clip=(18.0,39.8))
add('reveal','INTRODUCING RESQROAD',2.6)
add('system','ONE CONNECTED WORKFLOW',voice='IMG_0463',clip=(40.15,72.0))
add('problem-card','THE PROBLEM',1.1)
add('problem','CLOSING THE GAP',voice='IMG_0463',clip=(72.95,97.8))
add('residents-card','01 / FOR RESIDENTS',2)
add('residents','FOR RESIDENTS',voice='IMG_0514',clip=(.4,58.0))
add('map-card','SEE THE BIGGER PICTURE',1)
add('map','LIVE MAP & TRACKING',voice='IMG_0476',clip=(.6,18.1))
add('admin-card','02 / FOR LGU TEAMS',1.7)
add('admin','REVIEW & VERIFY',voice='IMG_0474',clip=(.7,33.35))
add('dispatch-card','03 / DISPATCH & REPAIR',1.4)
add('dispatch','TASK DISPATCH',voice='IMG_0474',clip=(33.65,46.55))
add('crew','ROAD CREWS',voice='IMG_0474',clip=(46.6,59.1))
add('insights-card','04 / INSIGHTS',1.5)
add('insights','INSIGHTS & STATISTICS',voice='IMG_0479',clip=(.05,18.9))
add('recap-card','FROM POTHOLE TO FIXED',1)
add('recap','FOUR SIMPLE STEPS',voice='IMG_0480',clip=(.2,7.5))
add('transparent','A CLEAR PATH FORWARD',voice='IMG_0483',clip=(0,6.4))
add('tested','THE COMPLETE JOURNEY',voice='IMG_0484',clip=(0,4.05))
add('cta-card','SAFER ROADS START HERE',1.2)
add('cta','BUILT FOR OUR COMMUNITIES',voice='IMG_0485',clip=(.85,12.45))
add('closing','REPORT IT. TRACK IT.',voice='IMG_0492',clip=(.45,10.15))
add('tagline','ONE REPORT CAN START IT',2)
add('meet','MEET THE GROUP',2)
for n in [1,2,3,5,4]:add('member-'+str(n),'',6)
add('end','SAFER ROADS START WITH ONE REPORT',4.85)

plans={
'opening':[(1,'logo','Safer roads start\nwith one report.')],
'hook':[(5,'road','Every day.\nThe same danger.'),(5,'problem','Damage.\nDisruption.\nUncertainty.'),(6.1,'question','Who is going\nto fix it?')],
'course-card':[(1,'chapter','A community problem.\nA web solution.')],
'course':[(9,'course','IT305','Advanced Web Development'),(6,'mission','Built around\na real problem.'),(6.8,'hero','Meet ResQRoad.','landing')],
'reveal':[(1,'logo','Introducing ResQRoad.')],
'system':[(7,'hero','One report.\nOne connected system.','landing'),(7,'roles','Three roles.\nOne platform.'),(7,'devices','Built for the way\nyou report.','landing'),(5,'flow','From the first photo…'),(5.85,'flow','…to the verified repair.')],
'problem-card':[(1,'chapter','Why ResQRoad?')],
'problem':[(6,'problem','No feedback.'),(6,'duplicates','The same problem.\nAgain. And again.'),(6,'problem','No clear picture.'),(6.85,'hero','Close the gap.','admin-dashboard')],
'residents-card':[(1,'chapter','For residents.')],
'residents':[(6,'hero','Report with\nconfidence.','resident-start'),(8,'screen','01  Describe the damage.','resident-details'),(8,'severity','Choose the right\nseverity.','resident-details'),(8,'screen','02  Pin the location.','resident-location'),(8,'screen','03  Add clear photos.','resident-photos'),(10,'screen','04  Review and submit.','resident-review'),(5,'screen','Your report.\nYour tracking ID.','resident-success'),(4.6,'screen','Follow every update.','my-reports')],
'map-card':[(1,'chapter','See what is already\non record.')],
'map':[(7,'hero','A clearer view\nof your community.','resident-map'),(5,'screen','Severity at a glance.','public-map'),(5.5,'screen','Track it by ID.','track-submitted')],
'admin-card':[(1,'chapter','For LGU teams.')],
'admin':[(6,'hero','One command center.','admin-dashboard'),(5,'screen','Know what needs attention.','admin-dashboard'),(6,'screen','Review the evidence.','admin-queue'),(6,'screen','Photos. Location. History.','admin-detail'),(5,'screen','Review before verification.','admin-under-review'),(4.65,'screen','Every decision recorded.','admin-verified')],
'dispatch-card':[(1,'chapter','The right crew.\nThe next step.')],
'dispatch':[(6.5,'hero','Verified.\nReady to assign.','dispatch'),(6.4,'screen','Balance the workload.','assigned')],
'crew':[(4,'screen','Start the assigned repair.','crew-start'),(5,'screen','Document the result.','crew-repair'),(3.5,'screen','Verified before closure.','crew-completed')],
'insights-card':[(1,'chapter','Turn reports\ninto insight.')],
'insights':[(6,'hero','See the progress.','analytics'),(6,'screen','Understand the patterns.','analytics-charts'),(6.85,'screen','Print. Export. Plan.','analytics')],
'recap-card':[(1,'chapter','From pothole to fixed.')],
'recap':[(1,'recap','Report. Verify.\nRepair. Resolve.')],
'transparent':[(1,'screen','A transparent workflow.','track-resolved')],
'tested':[(1,'flow','From the first photo\nto the closed report.')],
'cta-card':[(1,'chapter','Built for our communities.')],
'cta':[(5,'devices','Every resident\ndeserves safer roads.','landing'),(6.6,'logo','Better tools.\nA clearer way forward.')],
'closing':[(2,'cta','Report it.'),(2,'cta','Track it.'),(2.7,'cta','Watch your community’s\nroads get fixed.'),(3,'logo','Safer roads start\nwith one report.')],
'tagline':[(1,'logo','Safer roads start\nwith one report.')],
'meet':[(1,'chapter','Meet the Group')],
'end':[(1,'logo','Safer roads start\nwith one report.')],
}
shots=[]
for section in sections:
 if section['id'].startswith('member-'):
  plan=[(1,'member','',section['id'].split('-')[-1])]
 else:plan=plans[section['id']]
 total=sum(x[0] for x in plan);used=0
 for i,row in enumerate(plan):
  duration=section['durationInFrames']-used if i==len(plan)-1 else round(section['durationInFrames']*row[0]/total)
  shot={'id':f"{section['id']}-{i+1}",'section':section['id'],'chapter':section['label'],'startFrame':section['startFrame']+used,'durationInFrames':duration,'kind':row[1],'headline':row[2]}
  if len(row)>3:shot['asset']=row[3]
  shots.append(shot);used+=duration

captions=[]
for section in sections:
 if 'voice' not in section:continue
 v=section['voice'];pending=None
 for s,text in zip(raw[v['file']]['segments'],corrected[v['file']]):
  if s['start']<v['in']-.1 or s['start']>v['out']:continue
  a=max(0,s['start']-v['in'])+section['startFrame']/30
  b=min(v['out'],s['end'])-v['in']+section['startFrame']/30
  if b<=a:continue
  if pending and a-pending['end']<.85 and b-pending['start']<6.5 and len(pending['text']+' '+text)<96:
   pending['text']+=' '+text;pending['end']=b
  else:
   if pending:captions.append(pending)
   pending={'start':round(a,3),'end':round(b,3),'text':text}
 if pending:captions.append(pending)
for i,c in enumerate(captions):
 next_start=captions[i+1]['start'] if i+1<len(captions) else cursor/30
 c['end']=round(min(next_start-.04,max(c['end']+.12,c['start']+1.2)),3)
def stamp(t):
 ms=round(t*1000);h,ms=divmod(ms,3600000);m,ms=divmod(ms,60000);s,ms=divmod(ms,1000);return f'{h:02}:{m:02}:{s:02},{ms:03}'
srt='\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n"+'\n'.join(textwrap.wrap(c['text'],width=48)) for i,c in enumerate(captions))+'\n'
(root/'exports/ResQRoad_Promo_Subtitles.srt').write_text(srt)
members=json.loads((root/'inputs/member-photos/member-map.json').read_text())
for m in members:shutil.copy2(root/'inputs/member-photos'/m['file'],pub/f"member-{m['photo_number']}.jpg")
edit={'fps':30,'width':1920,'height':1080,'durationInFrames':cursor,'sections':sections,'shots':shots,'captions':captions,'members':members,'sourceCommit':'20d0a5d275482b9272b0db869d4272ebd61864af','narrationSource':'Supplied recordings; proper nouns and transcription errors corrected against guide/context.'}
(root/'production/edit.json').write_text(json.dumps(edit,indent=2)+'\n');(pub/'edit.json').write_text(json.dumps(edit,indent=2)+'\n')

def clean(name):
 source=next(p for p in (root/'inputs/voiceovers').glob(name+'.*') if p.suffix.lower() in ['.mov','.mp3','.wav','.m4a']);target=pub/'audio'/(name+'-master.wav')
 if target.exists():return
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source),'-map','0:a:0','-af','highpass=f=80,lowpass=f=11000,afftdn=nf=-35:tn=1,acompressor=threshold=0.12:ratio=2.8:attack=12:release=180,loudnorm=I=-17:TP=-2:LRA=9','-ar','48000','-ac','2',str(target)],check=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(clean,corrected))
audio_parts=[]
for n,section in enumerate(sections):
 dur=section['durationInFrames']/30;p=root/'state/audio'/f'part-{n:02}.wav'
 if 'voice' in section:
  v=section['voice'];source=pub/'audio'/(v['file']+'-master.wav')
  cmd=['-ss',str(v['in']),'-i',str(source),'-t',str(dur),'-af',f'afade=t=in:d=0.025,afade=t=out:st={max(0,dur-.045)}:d=0.045']
 else:cmd=['-f','lavfi','-i','anullsrc=r=48000:cl=stereo','-t',str(dur)]
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*cmd,'-ar','48000','-ac','2',str(p)],check=True);audio_parts.append(p)
list_file=root/'state/audio/dialogue-parts.txt';list_file.write_text('\n'.join(f"file '{p}'" for p in audio_parts))
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',str(list_file),'-c:a','pcm_s16le',str(pub/'dialogue.wav')],check=True)
print(json.dumps({'duration_seconds':cursor/30,'shots':len(shots),'captions':len(captions),'sections':len(sections)},indent=2))
