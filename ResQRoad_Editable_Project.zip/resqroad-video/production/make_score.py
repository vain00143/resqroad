"""Original instrumental score and transitions, generated without third-party samples."""
from pathlib import Path
import json,wave
import numpy as np
root=Path('/workspace/resqroad-video');edit=json.loads((root/'production/edit.json').read_text());sr=48000
duration=edit['durationInFrames']/30;n=round(duration*sr);track=np.zeros((n,2),np.float32)
rng=np.random.default_rng(305);beat=60/104;bar=beat*4
chords=[[53,57,60,64,67],[57,60,64,67,71],[48,52,55,59,62],[55,59,62,65,69]]
def note(start,length,midi,volume=.025,pan=0,kind='bell'):
 a=round(start*sr);count=min(round(length*sr),n-a)
 if count<=0:return
 t=np.arange(count,dtype=np.float32)/sr;f=440*2**((midi-69)/12)
 if kind=='pad':
  env=np.minimum(t/.6,1)*np.minimum((length-t)/.9,1)
  signal=np.sin(2*np.pi*f*t)+.25*np.sin(2*np.pi*(f*1.002)*t)+.13*np.sin(2*np.pi*2*f*t)
 else:
  env=np.minimum(t/.012,1)*np.exp(-t/(length*.32))
  signal=np.sin(2*np.pi*f*t)+.22*np.sin(2*np.pi*2*f*t)+.08*np.sin(2*np.pi*3*f*t)
 x=(signal*env*volume).astype(np.float32)
 track[a:a+count,0]+=x*np.sqrt((1-pan)/2);track[a:a+count,1]+=x*np.sqrt((1+pan)/2)
for b in range(int(duration/bar)+1):
 chord=chords[(b//2)%4];start=b*bar
 for j,midi in enumerate(chord):note(start,bar*1.4,midi+12,.006,pan=(j-2)/3,kind='pad')
 note(start,bar*.9,chord[0]-12,.018,pan=0,kind='pad')
 for step in range(8):
  midi=chord[[0,2,3,1,4,2,1,3][step]]+12
  note(start+step*beat/2,beat*1.5,midi,.016 if step%2==0 else .010,pan=.35 if step%2 else -.35)
 if b%4==3:note(start+2.5*beat,beat*2,chord[2]+24,.008,pan=.2)
 for step in range(4):
  a=round((start+step*beat)*sr);count=min(int(.15*sr),n-a)
  if count>0:
   t=np.arange(count)/sr;kick=np.sin(2*np.pi*(49*t+5*(1-np.exp(-t*22))))*np.exp(-t*28)*.018
   track[a:a+count,:]+=kick[:,None]
for section in edit['sections']:
 if section['id'].endswith('card') or section['id'] in ['reveal','meet']:
  start=section['startFrame']/30;a=max(0,round((start-.2)*sr));count=min(int(.6*sr),n-a)
  noise=rng.standard_normal(count).astype(np.float32);smooth=np.convolve(noise,np.ones(19)/19,mode='same')
  env=np.sin(np.linspace(0,np.pi,count))**2
  track[a:a+count,0]+=smooth*env*.025;track[a:a+count,1]+=smooth[::-1]*env*.025
fade=np.minimum(np.arange(n)/sr/2,1)*np.minimum((n-np.arange(n))/sr/4,1)
track*=fade[:,None]
p=root/'project/public/production/score-original.wav'
with wave.open(str(p),'wb') as f:f.setnchannels(2);f.setsampwidth(2);f.setframerate(sr);f.writeframes((np.clip(track,-1,1)*32767).astype(np.int16).tobytes())
print('Generated original instrumental score:',round(duration,2),'seconds')

def ass_time(t):
 cs=round(t*100);h,cs=divmod(cs,360000);m,cs=divmod(cs,6000);s,cs=divmod(cs,100);return f'{h}:{m:02}:{s:02}.{cs:02}'
header='''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Dialogue,Poppins,38,&H00FFFFFF,&H000000FF,&H001A120E,&H70000000,0,0,0,0,100,100,0,0,1,2.0,1,2,180,180,38,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''
import textwrap
events=[]
for c in edit['captions']:
 text='\\N'.join(textwrap.wrap(c['text'],width=62)).replace('{','').replace('}','')
 events.append(f"Dialogue: 0,{ass_time(c['start'])},{ass_time(c['end'])},Dialogue,,0,0,0,,{text}")
(root/'exports/ResQRoad_Promo_Subtitles.ass').write_text(header+'\n'.join(events)+'\n')
