from pathlib import Path
import json,subprocess,concurrent.futures
from PIL import Image
root=Path('/workspace/resqroad-video');pub=root/'project/public/production'
edit=json.loads((root/'production/edit.json').read_text());assets=sorted(set(s['asset'] for s in edit['shots'] if s['kind'] in ['screen','hero','severity']))
media={}
def prep(name):
 p=pub/(name+'.png');assert p.exists(),p
 im=Image.open(p);box=(240,100,1420,740) if im.size==(1440,900) else (0,0,im.width,im.height)
 if name=='crew-repair':box=(300,560,1400,900)
 if name=='crew-completed':box=(300,340,1400,900)
 focus=name+'-focus.png';im.crop(box).save(pub/focus)
 row={'image':p.name,'focusImage':focus,'focusAspect':(box[2]-box[0])/(box[3]-box[1])}
 v=pub/(name+'.mp4')
 if v.exists():
  data=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','json',str(v)]));row.update(video=v.name,videoDuration=float(data['format']['duration']))
  if box[0]:
   target=pub/(name+'-focus.mp4');x,y,x2,y2=box
   subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(v),'-vf',f'crop={x2-x}:{y2-y}:{x}:{y}','-c:v','libx264','-threads','1','-preset','fast','-crf','18','-an',str(target)],check=True)
   row['focusVideo']=target.name
 return name,row
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
 for name,row in ex.map(prep,assets):media[name]=row
(pub/'media.json').write_text(json.dumps(media,indent=2)+'\n')
print('Prepared',len(media),'screen assets; all required images exist.')
