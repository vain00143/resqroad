from pathlib import Path
import subprocess,json
root=Path('/workspace/resqroad-video');pub=root/'project/public/production';state=root/'state/audio'
pre=state/'mix-premaster.wav'
filters='[0:a]asplit=2[voice][side];[1:a]loudnorm=I=-26:TP=-6:LRA=7,aresample=48000[music];[music][side]sidechaincompress=threshold=0.06:ratio=3:attack=25:release=700[duck];[voice][duck]amix=inputs=2:duration=first:normalize=0,alimiter=limit=0.89:level=false[mix]'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(pub/'dialogue.wav'),'-i',str(pub/'score-original.wav'),'-filter_complex',filters,'-map','[mix]','-ar','48000','-ac','2','-c:a','pcm_s24le',str(pre)],check=True)
run=subprocess.run(['ffmpeg','-hide_banner','-i',str(pre),'-af','loudnorm=I=-15:TP=-1.5:LRA=9:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
stats=json.JSONDecoder().raw_decode(run.stderr[run.stderr.rfind('{'):])[0];(root/'production/loudness-analysis.json').write_text(json.dumps(stats,indent=2)+'\n')
af=f"loudnorm=I=-15:TP=-1.5:LRA=9:measured_I={stats['input_i']}:measured_TP={stats['input_tp']}:measured_LRA={stats['input_lra']}:measured_thresh={stats['input_thresh']}:offset={stats['target_offset']}:linear=true:print_format=json"
master=root/'exports/ResQRoad_Promo_Audio.wav'
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(pre),'-af',af,'-ar','48000','-ac','2','-c:a','pcm_s24le',str(master)],check=True)
print('Dialogue and original score mixed; two-pass -15 LUFS master saved.')
