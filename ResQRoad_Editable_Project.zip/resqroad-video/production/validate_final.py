from pathlib import Path
import subprocess,json,re
from PIL import Image,ImageDraw,ImageStat
root=Path('/workspace/resqroad-video');export=root/'exports';edit=json.loads((root/'production/edit.json').read_text());report={'source_commit':edit['sourceCommit'],'intended_frames':edit['durationInFrames'],'files':{},'credits':[]}
for name in ['ResQRoad_Promo_Final.mp4','ResQRoad_Promo_Captioned.mp4']:
 p=export/name
 info=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(p)]))
 v=next(x for x in info['streams'] if x['codec_type']=='video');a=next(x for x in info['streams'] if x['codec_type']=='audio')
 assert (v['width'],v['height'])==(1920,1080)
 assert v['codec_name']=='h264' and v['pix_fmt']=='yuv420p' and v['r_frame_rate']=='30/1'
 assert a['codec_name']=='aac' and a['channels']==2
 assert 300<=float(info['format']['duration'])<=600
 assert int(v['nb_frames'])==edit['durationInFrames']
 assert abs(float(v['duration'])-float(a['duration']))<.12
 run=subprocess.run(['ffmpeg','-hide_banner','-i',str(p),'-vf','blackdetect=d=0.3:pix_th=0.025:pic_th=0.98','-af','volumedetect','-f','null','-'],capture_output=True,text=True)
 (root/'production'/('qc-'+name+'.log')).write_text(run.stderr)
 assert run.returncode==0,name+' full decode failed'
 black=[{'start':float(a),'end':float(b),'duration':float(c)} for a,b,c in re.findall(r'black_start:([\d.]+) black_end:([\d.]+) black_duration:([\d.]+)',run.stderr)]
 unexpected=[x for x in black if x['start']>1 and x['end']<float(info['format']['duration'])-1]
 assert not unexpected,(name,unexpected)
 report['files'][name]={'duration':float(info['format']['duration']),'bytes':p.stat().st_size,'video_codec':v['codec_name'],'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'frames':int(v['nb_frames']),'audio_codec':a['codec_name'],'channels':a['channels'],'full_decode':'passed','unexpected_black_segments':unexpected,'intentional_edge_fades':black,'subtitle_tracks':sum(s['codec_type']=='subtitle' for s in info['streams'])}
 print('PASS:',name,'full decode, frame count, audio/video duration, and black-frame check',flush=True)
run=subprocess.run(['ffmpeg','-hide_banner','-i',str(export/'ResQRoad_Promo_Final.mp4'),'-vn','-af','loudnorm=I=-15:TP=-1:LRA=9:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
stats=json.JSONDecoder().raw_decode(run.stderr[run.stderr.rfind('{'):])[0]
report['audio_measurements']={'integrated_lufs':float(stats['input_i']),'true_peak_dbtp':float(stats['input_tp']),'loudness_range_lu':float(stats['input_lra'])}
assert -17<=report['audio_measurements']['integrated_lufs']<=-14
assert report['audio_measurements']['true_peak_dbtp']<=-1.0
frames=export/'QC_Frames';frames.mkdir(exist_ok=True)
times=[3.8,24,56,65,115,133,146,171,196,208,223,235,249,269,284,300]
for section in edit['sections']:
 if section['id'].startswith('member-'):
  t=(section['startFrame']+90)/30;times.append(t)
  m=next(m for m in edit['members'] if m['photo_number']==int(section['id'].split('-')[1]))
  report['credits'].append({'name':m['member_name'],'section':m['section'],'duration_seconds':section['durationInFrames']/30,'photo_number':m['photo_number'],'sample_time':t})
times.append(edit['durationInFrames']/30-2)
for i,t in enumerate(times):
 p=frames/f'{i:02}-{t:.2f}s.jpg'
 subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(t),'-i',str(export/'ResQRoad_Promo_Captioned.mp4'),'-frames:v','1','-q:v','2',str(p)],check=True)
 im=Image.open(p);assert sum(ImageStat.Stat(im).stddev)>12,(t,'empty frame')
for page in range((len(times)+5)//6):
 sheet=Image.new('RGB',(1920,760),'#25211D');draw=ImageDraw.Draw(sheet)
 for slot in range(6):
  i=page*6+slot
  if i>=len(times):break
  p=frames/f'{i:02}-{times[i]:.2f}s.jpg';im=Image.open(p).resize((640,360));x=(slot%3)*640;y=(slot//3)*380
  sheet.paste(im,(x,y+20));draw.text((x+10,y+3),f'{times[i]:.2f} seconds',fill='white')
 sheet.save(export/f'QC_Contact_{page+1}.jpg',quality=92)
report['caption_count']=len(edit['captions']);report['shot_count']=len(edit['shots']);report['all_ten_recordings_used']=len(set(s['voice']['file'] for s in edit['sections'] if 'voice'in s))==10
assert report['all_ten_recordings_used']
(export/'ResQRoad_Validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['audio_measurements']),flush=True)
print('All automated final checks passed; inspect contact sheets and representative frames.',flush=True)
