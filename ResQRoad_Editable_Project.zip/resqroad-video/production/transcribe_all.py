from pathlib import Path
import json,wave,time
import numpy as np
import sherpa_onnx
from faster_whisper.vad import get_speech_timestamps,VadOptions

root=Path('/workspace/resqroad-video')
model=root/'state/models/sherpa-onnx-whisper-tiny.en'
recognizer=sherpa_onnx.OfflineRecognizer.from_whisper(
 encoder=str(model/'tiny.en-encoder.int8.onnx'),decoder=str(model/'tiny.en-decoder.int8.onnx'),
 tokens=str(model/'tiny.en-tokens.txt'),language='en',task='transcribe',num_threads=3)
out={}
for p in sorted((root/'state/audio').glob('IMG_*.wav')):
 with wave.open(str(p)) as f:
  samples=np.frombuffer(f.readframes(f.getnframes()),np.int16).astype(np.float32)/32768
 regions=get_speech_timestamps(samples,VadOptions(min_silence_duration_ms=350,speech_pad_ms=130,max_speech_duration_s=16))
 segments=[]
 for region in regions:
  stream=recognizer.create_stream();stream.accept_waveform(16000,samples[region['start']:region['end']]);recognizer.decode_stream(stream)
  result=json.loads(str(stream.result))
  segments.append({'start':round(region['start']/16000,3),'end':round(region['end']/16000,3),'text':result['text'].strip()})
 out[p.stem]={'duration':round(len(samples)/16000,3),'segments':segments}
 (root/'production/transcripts-raw.json').write_text(json.dumps(out,indent=2)+'\n')
 print(p.stem, '\n'.join(s['text'] for s in segments),flush=True)
