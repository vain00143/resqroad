import path from 'node:path';import {fileURLToPath} from 'node:url';import {bundle} from '@remotion/bundler';
const root=path.dirname(fileURLToPath(import.meta.url));
console.log(await bundle({entryPoint:root+'/src/promo.jsx',publicDir:root+'/public',outDir:root+'/../state/promo-bundle'}));
