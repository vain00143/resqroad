const {chromium}=require('playwright');const fs=require('node:fs/promises');
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
 try{
  const c=await browser.newContext({viewport:{width:1440,height:900}});
  await c.addInitScript(()=>localStorage.setItem('resqroad-theme','light'));
  await c.route('**/*',r=>r.request().url().startsWith('http://127.0.0.1:8001')?r.continue():r.abort());
  const base='http://127.0.0.1:8001';const result=await c.request.post(base+'/api/auth/login',{data:{email:'juan.reyes@resqroad.ph',password:'crew123'}});if(result.status()!==200)throw Error('Login failed');
  const id=JSON.parse(await fs.readFile('/workspace/resqroad-video/production/demo-report.json')).id;
  const p=await c.newPage();await p.goto(base+'/maintenance.html',{waitUntil:'networkidle'});
  await p.locator('[data-crew-view=jobs]').click();await p.locator('[data-job-tab=done]').click();await p.locator('#job-search').fill(id);await p.waitForTimeout(800);
  await p.locator(`[data-toggle-job="${id}"]`).click();
  await p.locator('.repair-photos').first().scrollIntoViewIfNeeded();await p.waitForTimeout(700);
  await p.screenshot({path:'/workspace/resqroad-video/project/public/production/crew-completed.png'});
  console.log('Captured actual completed repair notes and after-repair evidence.');
  await c.close();
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
