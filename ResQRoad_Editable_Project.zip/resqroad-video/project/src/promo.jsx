import React,{useState,useEffect} from 'react';
import {AbsoluteFill,Composition,Img,OffthreadVideo,Freeze,Sequence,staticFile,useCurrentFrame,registerRoot,interpolate,delayRender,continueRender} from 'remotion';
import edit from '../public/production/edit.json';
import media from '../public/production/media.json';

const orange='#CF5C36',cream='#F6EEE5',muted='#B7AAA2';
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n));
const ease=n=>1-Math.pow(1-clamp(n),3);
const src=name=>staticFile('production/'+name);
const heading={fontFamily:'Archivo',fontWeight:800,letterSpacing:'-.045em',lineHeight:1.08};
const label={fontSize:20,fontWeight:600,letterSpacing:4,textTransform:'uppercase'};

function Icon({type='pin',size=64,color=orange}){
 const paths={pin:<><path d="M32 5c-12 0-21 9-21 21 0 16 21 34 21 34s21-18 21-34C53 14 44 5 32 5Z"/><circle cx="32" cy="26" r="7" fill="#181411"/></>,person:<><circle cx="32" cy="18" r="12"/><path d="M9 60V46c0-13 46-13 46 0v14Z"/></>,check:<path d="m10 33 14 14L55 15" fill="none" stroke={color} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round"/>,tools:<path d="m13 9 9 9-3 8-8-3-8-9c-5 22 10 31 23 25l22 22 12-12-22-22C44 14 35-1 13 9Z"/>,chart:<><rect x="7" y="35" width="10" height="25" rx="3"/><rect x="27" y="21" width="10" height="39" rx="3"/><rect x="47" y="5" width="10" height="55" rx="3"/></>,camera:<><path d="M6 17h12l5-8h18l5 8h12v38H6Z"/><circle cx="32" cy="35" r="12" fill="#181411"/></>};
 return <svg width={size} height={size} viewBox="0 0 64 64" fill={color}>{paths[type]||paths.pin}</svg>;
}
function Background({light=false,frame=0}){
 return <AbsoluteFill style={{background:light?'#F3EDE4':'#161310',overflow:'hidden'}}>
  <AbsoluteFill style={{background:light?'radial-gradient(ellipse at 90% 10%,#EFC88B88,transparent 62%)':'radial-gradient(ellipse at 82% 28%,#7B362155,transparent 55%),radial-gradient(ellipse at 12% 90%,#452E2288,transparent 60%)'}}/>
  <div style={{position:'absolute',left:-300,right:-300,bottom:-550,height:1000,transform:'perspective(1000px) rotateX(64deg)',backgroundImage:`linear-gradient(${light?'#BBA28D22':'#B3917522'} 1px,transparent 1px),linear-gradient(90deg,${light?'#BBA28D22':'#B3917522'} 1px,transparent 1px)`,backgroundSize:'100px 100px',opacity:.45}}/>
  <div style={{position:'absolute',top:0,bottom:0,left:70,width:1,background:light?'#B3998520':'#F0D6BC0C'}}/>
 </AbsoluteFill>;
}
function Brand({chapter='',light=false}){
 return <><Img src={staticFile(light?'logo-dark.png':'logo.png')} style={{position:'absolute',left:85,top:53,width:212}}/>
 <div style={{position:'absolute',right:85,top:62,...label,color:light?'#786250':muted,fontSize:16,letterSpacing:3}}>{chapter}</div></>;
}
function Lines({text,style={}}){return <div style={{whiteSpace:'pre-line',...heading,...style}}>{text}</div>;}
function Surface({asset,frame,width=1220,layout='browser',focus=false,video=false}){
 const item=media[asset]||{};
 const image=focus&&item.focusImage?item.focusImage:(item.image||asset+'.png');
 const path=focus&&item.focusVideo?item.focusVideo:item.video;
 const vframes=Math.max(1,Math.round((item.videoDuration||0)*30));
 return <div style={{width,position:'relative',borderRadius:layout==='monitor'?22:18,background:'#22201E',padding:layout==='monitor'?'14px 14px 32px':'0 0 8px',border:'1px solid #E8C9AF35',boxShadow:'0 24px 65px #0009',overflow:'visible'}}>
  {layout==='browser'&&<div style={{height:35,display:'flex',alignItems:'center',gap:9,paddingLeft:19,background:'#2B2622',borderRadius:'17px 17px 0 0'}}><i style={{width:8,height:8,borderRadius:9,background:'#C15F47'}}/><i style={{width:8,height:8,borderRadius:9,background:'#D6A66C'}}/><i style={{width:8,height:8,borderRadius:9,background:'#789580'}}/><span style={{fontSize:12,color:'#B6A99E',marginLeft:20,letterSpacing:1}}>ResQRoad</span></div>}
  <div style={{position:'relative',width:'100%',aspectRatio:focus?(item.focusAspect||'1.84'):'1.6',overflow:'hidden',background:'#F8F3ED',borderRadius:layout==='monitor'?8:0}}>
   <Img src={src(image)} style={{width:'100%',height:'100%',objectFit:'cover'}}/>
   {video&&path&&<AbsoluteFill><Freeze frame={Math.min(Math.max(0,frame),vframes-1)}><OffthreadVideo src={src(path)} muted style={{width:'100%',height:'100%',objectFit:'cover'}}/></Freeze></AbsoluteFill>}
  </div>
  {layout==='monitor'&&<><div style={{height:12,width:12,borderRadius:12,background:orange,position:'absolute',bottom:10,left:'50%',opacity:.75}}/><div style={{position:'absolute',width:170,height:75,left:'calc(50% - 85px)',top:'100%',background:'linear-gradient(90deg,#151412,#37332D,#191715)',clipPath:'polygon(24% 0,76% 0,88% 100%,12% 100%)'}}/><div style={{position:'absolute',width:370,height:21,left:'calc(50% - 185px)',top:'calc(100% + 70px)',borderRadius:20,background:'linear-gradient(#51463D,#1C1916)',boxShadow:'0 20px 35px #000A'}}/></>}
 </div>;
}
function Road({frame,headline}){
 return <><div style={{position:'absolute',right:-100,top:130,width:1220,height:880,transform:`perspective(1600px) rotateY(-14deg) rotateZ(-8deg) translateY(${Math.sin(frame/70)*8}px)`}}>
  <svg width="1200" height="850" viewBox="0 0 1200 850"><defs><linearGradient id="asphalt" x2="0" y2="1"><stop stopColor="#4D443D"/><stop offset="1" stopColor="#25211D"/></linearGradient><pattern id="noise" width="19" height="17" patternUnits="userSpaceOnUse"><circle cx="2" cy="3" r="1" fill="#FFFFFF" opacity=".07"/><circle cx="11" cy="12" r="1" fill="#000" opacity=".2"/></pattern></defs><path d="M300 30H810L1180 830H-120Z" fill="#100D0A" transform="translate(0,25)"/><path d="M300 0H810L1180 800H-120Z" fill="url(#asphalt)"/><path d="M300 0H810L1180 800H-120Z" fill="url(#noise)"/><path d="M310 0 30 800M800 0 1060 800" stroke="#AE9C8A" strokeWidth="7" opacity=".55"/>{Array.from({length:7},(_,i)=><path key={i} d={`M${546-i*5} ${i*125+(frame%60)}h${16+i*4}l5 62h-${26+i*4}Z`} fill="#E8C699" opacity=".8"/>)}<ellipse cx="760" cy="560" rx="162" ry="73" fill="#100E0C"/><ellipse cx="760" cy="549" rx="136" ry="49" fill="#29231D"/><path d="m607 565-55 30 10 28m337-63 64 30-12 24M702 493l-9-43M830 490l30-38" stroke="#16110D" strokeWidth="9" strokeLinecap="round"/></svg>
  <div style={{position:'absolute',left:710,top:200,transform:`translateY(${Math.sin(frame/12)*6}px)`,filter:'drop-shadow(0 12px 18px #0008)'}}><Icon size={150}/></div>
 </div><div style={{position:'absolute',left:100,top:300,width:690}}><div style={{...label,color:orange,marginBottom:30}}>A PROBLEM WE ALL RECOGNIZE</div><Lines text={headline} style={{fontSize:86}}/></div></>;
}
function Flow({frame,headline,recap=false}){
 const words=['Report','Verify','Repair','Resolve'];
 const icons=['camera','check','tools','check'];
 const active=recap?clamp(Math.floor((frame/30-3.2)/.85),-1,3):3;
 return <><div style={{position:'absolute',left:100,top:205}}><div style={{...label,color:orange,marginBottom:22}}>ONE TRANSPARENT WORKFLOW</div><Lines text={headline} style={{fontSize:74}}/></div><div style={{position:'absolute',left:100,right:100,top:520,display:'flex',gap:28}}>{words.map((word,i)=><React.Fragment key={word}><div style={{position:'relative',flex:1,padding:'43px 30px',height:270,borderRadius:24,border:`1px solid ${i<=active?'#CF5C3699':'#FFFFFF20'}`,background:i<=active?'linear-gradient(150deg,#632D1D,#2A201A)':'#251F1A',transform:`translateY(${Math.max(0,18-ease(frame/24-i*.13)*18)}px)`,boxShadow:'0 20px 40px #0005'}}><div style={{position:'absolute',top:20,right:25,fontSize:18,color:muted}}>0{i+1}</div><Icon type={icons[i]} size={60} color={i===3&&active===3?'#AFCBAD':orange}/><div style={{...heading,fontSize:39,marginTop:30}}>{word}</div></div>{i<3&&<div style={{alignSelf:'center',fontSize:42,color:'#9E7455'}}>→</div>}</React.Fragment>)}</div></>;
}
function Scene({shot,frame}){
 const progress=clamp(frame/Math.max(1,shot.durationInFrames-1));const entrance=ease(frame/35);
 const kind=shot.kind;const light=['course','member'].includes(kind);
 const isScreen=['hero','screen','severity'].includes(kind);
 const suffix=shot.id.endsWith('-2')?-1:1;
 const activeVideo=['resident-details','resident-location','resident-photos','resident-review','resident-success','admin-queue','admin-under-review','admin-verified','crew-start','crew-repair','crew-submitted'].includes(shot.asset);
 return <AbsoluteFill style={{color:light?'#211A15':cream,fontFamily:'Poppins',overflow:'hidden'}}>
 <Background light={light} frame={frame}/>
 {kind!=='member'&&<Brand chapter={shot.chapter} light={light}/>}
 {['logo','cta'].includes(kind)&&<>
  <div style={{position:'absolute',width:1000,height:1000,border:'1px solid #CF5C3635',borderRadius:'50%',left:460,top:-40,transform:`scale(${.9+progress*.15})`}}/><div style={{position:'absolute',width:760,height:760,border:'1px solid #CF5C3622',borderRadius:'50%',left:580,top:80}}/>
  <div style={{position:'absolute',left:110,right:110,top:kind==='cta'?330:260,textAlign:'center',transform:`translateY(${(1-entrance)*24}px)`}}>{kind==='logo'&&<Img src={staticFile('logo.png')} style={{width:560,marginBottom:65}}/>}<Lines text={shot.headline} style={{fontSize:kind==='cta'?116:76,lineHeight:1.13}}/>{kind==='logo'&&shot.section==='end'&&<div style={{...label,color:'#C7966D',marginTop:45}}>REPORT · VERIFY · REPAIR · RESOLVE</div>}</div>
 </>}
 {kind==='road'&&<Road frame={frame} headline={shot.headline}/>}
 {['problem','question'].includes(kind)&&<>
  <div style={{position:'absolute',left:105,top:270,width:1420}}><div style={{...label,color:orange,marginBottom:35}}>{kind==='question'?'ONE QUESTION REMAINS':'THE REPORTING GAP'}</div><Lines text={shot.headline} style={{fontSize:kind==='question'?113:104}}/></div><div style={{position:'absolute',right:140,bottom:155,opacity:.17,transform:`rotate(-12deg) scale(${1+progress*.1})`}}><Icon size={400} color={orange}/></div>
 </>}
 {kind==='duplicates'&&<><div style={{position:'absolute',left:105,top:285,width:800}}><div style={{...label,color:orange,marginBottom:35}}>DUPLICATE REPORTS</div><Lines text={shot.headline} style={{fontSize:86}}/></div>{[0,1,2].map(i=><div key={i} style={{position:'absolute',left:1020+i*58,top:250+i*108,width:590,padding:36,borderRadius:20,border:'1px solid #E0AB7A55',background:'#30251E',transform:`rotate(${i*3-6}deg) translateY(${(1-ease(frame/25-i*.15))*50}px)`,boxShadow:'0 25px 50px #0008'}}><div style={{display:'flex',gap:24,alignItems:'center'}}><Icon size={55}/><div><div style={{fontSize:20,color:muted}}>Same damaged road</div><div style={{fontSize:31,fontWeight:600}}>Reported again…</div></div></div></div>)}</>}
 {kind==='chapter'&&<>
  <div style={{position:'absolute',left:110,top:245,width:1550,transform:`translateX(${(1-entrance)*50}px)`}}><div style={{height:7,width:130,background:orange,marginBottom:45}}/><div style={{...label,color:'#D9B08C',marginBottom:30}}>{shot.section==='meet'?'BSIT 3H-G2 · GROUP 1':'RESQROAD'}</div><Lines text={shot.headline} style={{fontSize:100,lineHeight:1.14}}/></div><div style={{position:'absolute',right:-70,bottom:-170,width:850,height:850,border:'2px solid #CF5C3633',borderRadius:'50%',transform:`scale(${.8+progress*.15})`}}/>
 </>}
 {kind==='course'&&<><div style={{position:'absolute',left:110,top:255,width:1250}}><div style={{...label,color:'#8C4B32',marginBottom:25}}>BSIT 3H-G2 · GROUP 1</div><Lines text="IT305" style={{fontSize:190,color:'#B34F2F'}}/><Lines text={'Advanced Web\nDevelopment'} style={{fontSize:80,marginTop:28}}/></div><div style={{position:'absolute',right:180,top:300,width:160,height:320,borderRight:'12px solid #CF5C36',transform:'skew(-12deg)'}}/></>}
 {kind==='mission'&&<><div style={{position:'absolute',left:110,top:225,width:1100}}><div style={{...label,color:orange,marginBottom:30}}>FROM CLASSROOM TO COMMUNITY</div><Lines text={shot.headline} style={{fontSize:100}}/><div style={{fontSize:32,color:muted,marginTop:45,maxWidth:1100}}>A web application for road damage reporting<br/>and maintenance coordination.</div></div><div style={{position:'absolute',right:150,top:390}}><Icon type="tools" size={230}/></div></>}
 {isScreen&&<>
  {kind==='hero'?<>
   <div style={{position:'absolute',left:100,top:300,width:500}}><div style={{...label,color:orange,fontSize:17,marginBottom:32}}>{shot.section==='residents'?'EASY TO REPORT':'CLEAR AT EVERY STEP'}</div><Lines text={shot.headline} style={{fontSize:70}}/><div style={{fontSize:21,color:muted,marginTop:35}}>ResQRoad · Product demonstration</div></div>
   <div style={{position:'absolute',left:670,top:195,transformOrigin:'center center',transform:`perspective(2400px) rotateY(${-15+entrance*5+progress*3}deg) rotateX(3deg) rotateZ(-1deg) scale(${.91+entrance*.025+progress*.015})`}}><Surface asset={shot.asset} frame={frame} width={1120} layout="monitor"/></div>
  </>:<>
   <Lines text={shot.headline.replace('\n',' ')} style={{position:'absolute',left:105,top:133,fontSize:48,letterSpacing:'-.025em'}}/>
   <div style={{position:'absolute',left:230,top:215,transform:`perspective(2800px) rotateY(${(1-entrance)*suffix*8}deg) translateY(${(1-entrance)*24}px) scale(${.99+progress*.014})`,transformOrigin:'center top'}}><Surface asset={shot.asset} frame={frame} width={1460} focus video={activeVideo}/></div>
  </>}
  <div style={{position:'absolute',right:100,bottom:135,fontSize:15,color:'#E6C5AA',letterSpacing:2}}>DEMO DATA</div>
  {['map','resident-map','public-map','admin-map'].includes(shot.asset)&&<div style={{position:'absolute',left:110,bottom:135,fontSize:16,color:muted}}>© OpenStreetMap contributors</div>}
  {kind==='severity'&&<div style={{position:'absolute',left:160,right:160,bottom:160,display:'flex',gap:20}}>{[['LOW','#7D9C7A'],['MEDIUM','#D3A355'],['HIGH','#CC5848']].map(([t,c])=><div key={t} style={{flex:1,padding:'22px 32px',background:'#211A16F5',borderRadius:16,border:`1px solid ${c}`,fontSize:26,fontWeight:600,boxShadow:'0 10px 30px #0008'}}><span style={{color:c,marginRight:16}}>●</span>{t}</div>)}</div>}
 </>}
 {kind==='roles'&&<>
  <Lines text={shot.headline} style={{position:'absolute',left:110,top:180,fontSize:80}}/>
  <div style={{position:'absolute',left:110,right:110,top:450,display:'flex',gap:34}}>{[['Residents','Report the damage','person'],['Administrators','Verify and assign','check'],['Road crews','Repair and document','tools']].map(([name,task,icon],i)=><div key={name} style={{flex:1,height:360,padding:45,border:'1px solid #C9997255',borderRadius:24,background:'linear-gradient(135deg,#3A2B22,#211A16)',transform:`perspective(1600px) rotateY(${(i-1)*-7}deg) translateY(${(1-ease(frame/30-i*.13))*40}px)`}}><Icon type={icon} size={80}/><div style={{...heading,fontSize:38,marginTop:45}}>{name}</div><div style={{fontSize:26,color:muted,marginTop:18}}>{task}</div></div>)}</div>
 </>}
 {kind==='devices'&&<>
  <div style={{position:'absolute',left:100,top:205,width:600}}><div style={{...label,color:orange,marginBottom:30}}>WEB & MOBILE-FRIENDLY</div><Lines text={shot.headline} style={{fontSize:76}}/></div>
  <div style={{position:'absolute',left:680,top:220,transform:`perspective(1800px) rotateY(-12deg) scale(${.82+progress*.018})`,transformOrigin:'left top'}}><Surface asset="landing" frame={frame} width={1270} layout="monitor"/></div>
  <div style={{position:'absolute',left:670,top:350,width:260,padding:10,borderRadius:44,background:'#141311',border:'2px solid #B99D8288',transform:`perspective(1800px) rotateY(-8deg) rotateZ(-5deg) translateY(${Math.sin(frame/80)*5}px)`,boxShadow:'0 25px 50px #0009'}}><Img src={src(shot.section==='cta'?'mobile-reports.png':'mobile-landing.png')} style={{width:236,borderRadius:32,display:'block'}}/><div style={{position:'absolute',top:16,left:90,width:80,height:15,background:'#111',borderRadius:20}}/></div>
 </>}
 {['flow','recap'].includes(kind)&&<Flow frame={frame} headline={shot.headline} recap={kind==='recap'}/>}
 {kind==='member'&&(()=>{const member=edit.members.find(m=>m.photo_number===Number(shot.asset));return <>
  <div style={{position:'absolute',left:115,top:365,width:840,transform:`translateY(${(1-entrance)*25}px)`}}><div style={{height:6,width:100,background:orange,marginBottom:35}}/><Lines text={member.member_name} style={{fontSize:70,lineHeight:1.2}}/><div style={{fontSize:32,color:'#836750',marginTop:35,letterSpacing:4}}>{member.section}</div></div>
  <div style={{position:'absolute',left:1110,top:68,width:640,height:930,background:'#E8E1D6',borderRadius:24,overflow:'hidden',boxShadow:'0 28px 60px #3E2E242A',transform:`translateY(${(1-entrance)*20}px) scale(${1+progress*.008})`}}><Img src={src('member-'+shot.asset+'.jpg')} style={{width:'100%',height:'100%',objectFit:'contain'}}/></div>
 </>;})()}
 </AbsoluteFill>;
}
function Promo(){
 const [fontHandle]=useState(()=>delayRender('Loading local brand fonts'));
 useEffect(()=>{Promise.all([document.fonts.load('800 80px Archivo'),document.fonts.load('400 38px Poppins'),document.fonts.load('600 38px Poppins')]).then(()=>document.fonts.ready).then(()=>continueRender(fontHandle));},[fontHandle]);
 const frame=useCurrentFrame();let index=edit.shots.findIndex(s=>frame>=s.startFrame&&frame<s.startFrame+s.durationInFrames);if(index<0)index=edit.shots.length-1;
 const shot=edit.shots[index],local=frame-shot.startFrame,enter=clamp(local/12);
 const fadeOut=shot.section==='end'?clamp((edit.durationInFrames-frame)/25):1;
 return <AbsoluteFill style={{background:'#161310',opacity:fadeOut}}>
 <style>{`@font-face{font-family:Archivo;src:url('${src('ArchivoExpanded-ExtraBold.ttf')}')}@font-face{font-family:Poppins;src:url('${src('Poppins-Regular.ttf')}');font-weight:400}@font-face{font-family:Poppins;src:url('${src('Poppins-SemiBold.ttf')}');font-weight:600}*{box-sizing:border-box}`}</style>
 {index>0&&enter<1&&<AbsoluteFill style={{opacity:1-enter}}><Scene shot={edit.shots[index-1]} frame={edit.shots[index-1].durationInFrames-1}/></AbsoluteFill>}
 <AbsoluteFill style={{opacity:index===0?clamp(local/14):enter}}><Scene shot={shot} frame={local}/></AbsoluteFill>
 <div style={{position:'absolute',left:0,right:0,bottom:0,height:128,background:'linear-gradient(transparent,#100D0BD9)',pointerEvents:'none',display:['member','course'].includes(shot.kind)?'none':'block'}}/>
 </AbsoluteFill>;
}
registerRoot(()=> <Composition id="ResQRoadPromo" component={Promo} durationInFrames={edit.durationInFrames} fps={30} width={1920} height={1080}/>);
