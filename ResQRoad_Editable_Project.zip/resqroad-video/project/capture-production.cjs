const {chromium,request}=require('playwright');
const fs=require('node:fs/promises');
const path=require('node:path');
const assert=require('node:assert/strict');
const {execFile}=require('node:child_process');const {promisify}=require('node:util');
const root='/workspace/resqroad-video';const dest=root+'/project/public/production';
const base='http://127.0.0.1:8001';
const shots={};
async function main(){
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 const remote=await request.newContext({proxy:{server:process.env.HTTPS_PROXY},timeout:20000});
 const cache=new Map();
 const contexts=[];
 async function context(email,password){
  const ctx=await browser.newContext({viewport:{width:1440,height:900},deviceScaleFactor:1,reducedMotion:'reduce'});contexts.push(ctx);
  await ctx.addInitScript(()=>localStorage.setItem('resqroad-theme','light'));
  await ctx.route('**/*',async route=>{
   const url=route.request().url();if(url.startsWith(base)||!url.startsWith('http'))return route.continue();
   if(/https:\/\/(npr\.brightspotcdn\.com|images\.ndr\.de|media-cache\.primedia-service\.com)\//.test(url))return route.abort();
   try{
    if(!cache.has(url))cache.set(url,(async()=>{const r=await remote.get(url);return {status:r.status(),headers:r.headers(),body:await r.body()};})());
    const result=await cache.get(url);await route.fulfill(result);
   }catch{return route.abort();}
  });
  if(email){const login=await ctx.request.post(base+'/api/auth/login',{data:{email,password}});assert.equal(login.status(),200,email);}
  const p=await ctx.newPage();p.setDefaultTimeout(15000);return p;
 }
 async function snap(p,name){
  await p.waitForTimeout(500);await p.evaluate(()=>document.fonts.ready);
  const file=name+'.png';await p.screenshot({path:dest+'/'+file});shots[name]={image:file};
  await fs.writeFile(root+'/production/captures.json',JSON.stringify(shots,null,2));console.log('Captured',name);
 }
 async function record(p,name,action,hold=1200){
  const dir=root+'/state/capture/'+name+'-'+Date.now();await fs.mkdir(dir,{recursive:true});
  const session=await p.context().newCDPSession(p);const frames=[];const pending=[];
  session.on('Page.screencastFrame',ev=>{const file=path.join(dir,String(frames.length).padStart(6,'0')+'.jpg');frames.push({file,time:ev.metadata.timestamp});pending.push(fs.writeFile(file,Buffer.from(ev.data,'base64')));session.send('Page.screencastFrameAck',{sessionId:ev.sessionId}).catch(()=>{});});
  await session.send('Page.startScreencast',{format:'jpeg',quality:90,maxWidth:1440,maxHeight:900,everyNthFrame:1});
  await p.waitForTimeout(450);await action();await p.waitForTimeout(hold);
  await session.send('Page.stopScreencast');await Promise.all(pending);await session.detach();
  await snap(p,name);
  if(frames.length>1){const lines=frames.map((f,i)=>`file '${f.file}'\nduration ${i<frames.length-1?Math.max(.001,frames[i+1].time-f.time):.8}`);lines.push(`file '${frames.at(-1).file}'`);await fs.writeFile(dir+'/frames.txt',lines.join('\n'));
   await promisify(execFile)('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','concat','-safe','0','-i',dir+'/frames.txt','-r','30','-c:v','libx264','-threads','2','-preset','fast','-crf','18','-pix_fmt','yuv420p',dest+'/'+name+'.mp4']);shots[name].video=name+'.mp4';
   await fs.writeFile(root+'/production/captures.json',JSON.stringify(shots,null,2));
  }
 }
 const confirm=async p=>{const b=p.locator('[data-dialog-accept]');if(await b.count())await b.click();};
 try{
  const pub=await context();await pub.goto(base+'/',{waitUntil:'networkidle'});await snap(pub,'landing');
  await record(pub,'public-map',async()=>{await pub.locator('#live-map').scrollIntoViewIfNeeded();await pub.waitForTimeout(700);},1500);
  const resident=await context('maria.santos@example.com','citizen123');
  let reportId;try{reportId=JSON.parse(await fs.readFile(root+'/production/demo-report.json','utf8')).id;}catch{}
  await resident.goto(base+'/citizen.html',{waitUntil:'networkidle'});await snap(resident,'resident-start');
  if(!reportId){
  await record(resident,'resident-details',async()=>{
   await resident.locator('[name=title]').pressSequentially('Deep pothole near the community crossing',{delay:35});
   await resident.locator('label').filter({has:resident.locator('[name=severity][value=High]')}).click();
   await resident.locator('textarea[name=description]').fill('A deep pothole is forcing vehicles to swerve near the crossing. Please inspect and repair this road.');
  });
  await resident.locator('[data-step-next]').click();await resident.waitForTimeout(800);
  await record(resident,'resident-location',async()=>{
   for(const [name,value] of Object.entries({latitude:'14.990100',longitude:'120.990100',road:'MacArthur Highway',barangay:'Guinhawa',municipality:'Malolos City, Bulacan'}))await resident.locator(`[name=${name}]`).fill(value);
   await resident.locator('[name=longitude]').blur();
  });
  await resident.locator('[data-step-next]').click();
  await record(resident,'resident-photos',async()=>{await resident.locator('#evidence-input').setInputFiles(dest+'/evidence-demo.png');},1600);
  await record(resident,'resident-review',async()=>{await resident.locator('[data-step-next]').click();},1000);
   await record(resident,'resident-success',async()=>{
    await resident.locator('[data-step-submit]').click();await resident.waitForTimeout(700);await confirm(resident);
    await resident.locator('#report-success').waitFor({state:'visible'});
   });
   reportId=(await resident.locator('#report-success').innerText()).match(/RPT-\d+/)[0];
   await fs.writeFile(root+'/production/demo-report.json',JSON.stringify({id:reportId,title:'Deep pothole near the community crossing'}));
  }
  await resident.goto(base+'/citizen.html#reports',{waitUntil:'networkidle'});await snap(resident,'my-reports');
  await resident.goto(base+'/citizen.html#map',{waitUntil:'networkidle'});await snap(resident,'resident-map');
  await resident.goto(base+'/citizen.html#track',{waitUntil:'networkidle'});await resident.locator('#portal-track-input').fill(reportId);await resident.locator('#portal-track-form button').click();await snap(resident,'track-submitted');
  const admin=await context('admin@resqroad.ph','admin123');await admin.goto(base+'/admin.html',{waitUntil:'networkidle'});await snap(admin,'admin-dashboard');
  const currentReport=await (await admin.context().request.get(base+'/api/reports/'+reportId)).json();
  if(currentReport.report.status==='submitted'){
  await record(admin,'admin-queue',async()=>admin.locator('[data-admin-view=reports]').click());
  await record(admin,'admin-detail',async()=>admin.locator(`[data-action=open][data-report-id="${reportId}"]:visible`).first().click());
  await record(admin,'admin-under-review',async()=>{await admin.locator('[data-next-status=under_review]').click();await confirm(admin);});
  await record(admin,'admin-verified',async()=>{await admin.locator('[data-next-status=verified]').click();await confirm(admin);});
  }
  if(await admin.locator('#drawer-close').isVisible())await admin.locator('#drawer-close').click();await admin.locator('[data-admin-view=assignments]').click();await snap(admin,'dispatch');
  // Assign through the same documented backend used by the interface; capture the real resulting workspace.
  const data=await (await admin.context().request.get(base+'/api/state')).json();const crew=data.users.find(u=>u.email==='juan.reyes@resqroad.ph');
  const assigned=await admin.context().request.post(base+'/api/reports/'+reportId+'/assign',{data:{crewId:crew.id}});assert.equal(assigned.status(),200);
  await admin.waitForTimeout(800);await snap(admin,'assigned');
  const worker=await context('juan.reyes@resqroad.ph','crew123');await worker.goto(base+'/maintenance.html',{waitUntil:'networkidle'});await snap(worker,'crew-overview');
  await worker.locator('[data-crew-view=jobs]').click();await worker.locator('#job-search').fill(reportId);await worker.waitForTimeout(500);await snap(worker,'crew-job');
  await record(worker,'crew-start',async()=>worker.locator(`[data-action=start][data-report-id="${reportId}"]`).click());
  await worker.locator(`[data-open-job="${reportId}"]`).first().click().catch(()=>{});
  const repair=worker.locator(`form[data-repair-form][data-report-id="${reportId}"]`);
  await record(worker,'crew-repair',async()=>{await repair.locator('[name=notes]').fill('Damaged asphalt removed and the road surface repaired. The site is ready for inspection.');await repair.locator('input[type=file]').setInputFiles(dest+'/repair-demo.png');},1200);
  await record(worker,'crew-submitted',async()=>{await repair.locator('button[type=submit]').click();await confirm(worker);},1800);
  await admin.goto(base+'/admin.html#reports',{waitUntil:'networkidle'});
  const resolution=await admin.context().request.post(base+'/api/reports/'+reportId+'/status',{data:{status:'resolved'}});assert.equal(resolution.status(),200);
  await admin.goto(base+'/admin.html#analytics',{waitUntil:'networkidle'});await snap(admin,'analytics');
  await admin.evaluate(()=>window.scrollBy({top:450,behavior:'instant'}));await snap(admin,'analytics-charts');
  await admin.goto(base+'/admin.html#maps',{waitUntil:'networkidle'});await snap(admin,'admin-map');
  await pub.goto(base+'/index.html?track='+reportId+'#track',{waitUntil:'networkidle'});await pub.locator('#track-result').scrollIntoViewIfNeeded();await snap(pub,'track-resolved');
  await resident.goto(base+'/citizen.html#reports',{waitUntil:'networkidle'});await snap(resident,'resident-resolved');
  await resident.setViewportSize({width:390,height:844});await resident.goto(base+'/citizen.html#reports',{waitUntil:'networkidle'});await snap(resident,'mobile-reports');
  await pub.setViewportSize({width:390,height:844});await pub.goto(base+'/',{waitUntil:'networkidle'});await snap(pub,'mobile-landing');
  console.log('Production captures complete for',reportId);
 }finally{for(const c of contexts)await c.close();await browser.close();await remote.dispose();}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
