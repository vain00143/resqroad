import path from 'node:path';import fs from 'node:fs/promises';import {fileURLToPath} from 'node:url';
import {bundle} from '@remotion/bundler';import {selectComposition,renderStill,openBrowser} from '@remotion/renderer';
const root=path.dirname(fileURLToPath(import.meta.url));const edit=JSON.parse(await fs.readFile(root+'/../production/edit.json'));
const serveUrl=await bundle({entryPoint:root+'/src/promo.jsx',publicDir:root+'/public',outDir:root+'/../state/promo-bundle'});
await fs.writeFile(root+'/../production/bundle-path.txt',serveUrl);
const browser=await openBrowser('chrome',{browserExecutable:'/usr/bin/chromium',logLevel:'warn'});
try{
 const composition=await selectComposition({serveUrl,id:'ResQRoadPromo',puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium'});
 await fs.mkdir(root+'/../production/previews',{recursive:true});
 for(const id of ['hook-1','course-1','system-2','system-3','residents-2','admin-4','crew-2','insights-1','member-1-1','end-1']){
  const shot=edit.shots.find(s=>s.id===id);const frame=shot.startFrame+Math.min(60,Math.floor(shot.durationInFrames/2));
  await renderStill({serveUrl,composition,frame,puppeteerInstance:browser,browserExecutable:'/usr/bin/chromium',output:root+'/../production/previews/'+id+'.png',logLevel:'warn'});
  console.log('Preview',id,'frame',frame);
 }
}finally{await browser.close({silent:true});}
