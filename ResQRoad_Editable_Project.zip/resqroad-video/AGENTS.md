# Video production instructions

- Read README.md before work. Use the existing develop checkout; no Git worktrees unless explicitly requested.
- The user wants a 5–10 minute promotional film using the actual voiceovers, photos, guide, and develop app. The guide's exact timeline and dates are flexible.
- Preserve application source and existing user work. Keep video sources and generated outputs here.
- Build and inspect the actual exported film; project code alone is not a completed video.
- Use the current develop behavior for claims and labels. Main's browser-only prototype differs substantially.
- Use the user-confirmed member-map.json: photos 1 Elizur, 2 Paul Benedick, 3 Lourence, 4 Vencee, 5 Ivan Matthew. Use Paul Benedick as the user spelled it.
- All ten recordings are available in inputs/voiceovers/; see inventory.json. IMG_0463.mp3 replaces the oversized MOV. Combined duration is about 4:58. Do not synthesize speaker voices or invent attributed narration without permission.
- The technical test uses a labeled tone and is not the finished promo.
- Read inputs/references/references.md for the user's chosen visual direction: perspective desktop/browser mockups on dark studio backgrounds, restrained edge lighting in ResQRoad colors, smooth camera-style motion, and transitions into readable actual UI. Preferred reference ranges: first link 00:11–00:22; second link 00:10–00:45. The supplied screenshots are illustrative, not footage to insert.
- Read README.md's startup and network limitations; do not claim transcription or reference analysis before verifying them.
- Never disclose or archive state/app.env, state/database.env, database data, or browser sessions. The source archive excludes state/.
