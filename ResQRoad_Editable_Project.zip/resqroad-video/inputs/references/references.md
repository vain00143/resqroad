# Creative references

The reference videos have not been directly viewed by the setup agent. The user supplied two illustrative screenshots in chat and identified these preferred transition/editing ranges:

- First link: 00:11–00:22 (k2maqlyUuVw).
- Second link: 00:10–00:45 (wwIt5ZvROrs).

The timestamps are reference-video ranges, not required positions in the ResQRoad film.

- https://www.youtube.com/watch?v=k2maqlyUuVw
- https://www.youtube.com/watch?v=wwIt5ZvROrs
- https://www.youtube.com/watch?v=SgmuplXU2iY
- https://youtu.be/IpQaCTm5RKA?si=WO4NIn5BAhP_Xlvv

Review pacing, typography, screen framing, transitions, and sound design if access is available. Do not copy third-party media or invent observations. Screenshots or authorized short clips and timestamp notes can supplement inaccessible pages.

## User-confirmed visual direction

The screenshots are examples of the desired treatment, not assets to insert into the film or exact templates to copy.

Observed in screenshot one: a desktop monitor at a strong perspective angle, a charcoal studio setting, dark device geometry, soft contact shadows, and a clean webpage presented as the main subject.

Observed in screenshot two: a floating browser window at an oblique angle, a dark backdrop, soft colored edge glow, a large focused application surface, and a prominent cursor near an interface element.

Adapt these traits with actual develop captures, ResQRoad logos, orange/rust edge accents, charcoal backgrounds, and the brand typography. Proposed motion direction: smooth perspective rotation and dolly-like moves, a screen moving toward the camera into a readable full-frame view, brief focused cursor/click highlights, and cuts matching the narration. These are proposed adaptations based on the stills; their exact timing has not been verified from the videos.

Use angled floating screens for product introductions, section bridges, and feature reveals. Flatten and enlarge the actual interface for demonstrations where labels and actions must be read. Keep the application itself accurate; change its presentation frame, not its functionality. Use restrained depth, lighting, motion blur, and sound accents. Avoid constant tilting, excessive glow, and effects that obscure the product.

The earlier 8-second technical test verifies the toolchain only. Its flat layout and test tone do not define the final creative direction.
